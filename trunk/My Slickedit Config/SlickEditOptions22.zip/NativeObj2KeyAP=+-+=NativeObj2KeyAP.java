/*========================================================================
 * - COPYRIGHT NOTICE -                                                  *
 *                                                                       *
 * (c) Copyright 2000-2016 TIBCO Software Inc. All rights reserved.      *
 * TIBCO Confidential & Proprietary                                      *
 *                                                                       *
 ========================================================================*/

package com.openspirit.plugin.data.petra.v3.mapped.petra;

import java.sql.Timestamp;

import com.openspirit.InvalidTypeException;
import com.openspirit.data.OspSQLException;
import com.openspirit.metamodel.AttributeDefinition;
import com.openspirit.plugin.data.common.MapCacheWithTimeout;
import com.openspirit.plugin.data.common.QueryUtils;
import com.openspirit.plugin.data.petra.v3.mapped.Petra3TableConnection;
import com.openspirit.plugin.data.petra.v3.mapped.Petra3Utils;
import com.openspirit.spi.data.table.QueryException;
import com.openspirit.spi.data.type.DataValue;
import com.openspirit.spi.data.type.SetableDataValue;
import com.openspirit.unit.DoubleQuantity;

/**
 * Structure containing relevant $fileinputname$ attributes used for OSP mappings.
 */
public final class $fileinputname$ {

    /**
     * The native entity name.
     */
    public final static String TABLE = "$fileinputname$";

    /**
     * The name of the primary key attribute.
     */
    public static final String $Key1$ = "$Key1$";
    public static final String $Key2$ = "$Key2$";

    public static final int MAX_LEN_REMARKS = 4096;
    public static final int MAX_LEN_NAME = 30;
    public static final int MAX_LEN_SOURCE = 8;

    // TODO: Constants
    //public static final int RUN_NUMBER    = 1;
    //public static final String INDEX_KIND = "MD";

    // Members are named 'm_' + the petra attribute name.
    public Integer m_$Key1$;
    public Integer m_$Key2$;

    private String m_key; // saves the key for the particular record.

    /**
     * Constructor.
     *
     * @param connection the connection.
     */
    public $fileinputname$() {
    }

    /**
     * Creates a $fileinputname$ key.
     *
     * @param $Key1$ key segment.
     * @param $Key2$ key segment.
     * @return the key.
     */
    public static String makeKey(String $Key1$, String $Key2$) {
        StringBuilder sb = new StringBuilder();
        sb.append($Key1$);
        sb.append(Access.KEY_SEPARATOR);
        if ($Key2$ != null) {
            sb.append($Key2$);
        }
        return sb.toString();
    }

    /**
     * @return create and return a key based on wsn and $Key2$
     */
    private synchronized String getKey() {
        if (m_key == null) {
            m_key = makeKey(m_$Key1$.toString(), m_$Key2$.toString());
        }
        return m_key;
    }

    /**
     * Access class for $fileinputname$.
     */
    public static class Access extends PetraReader<$fileinputname$> {

        private static com.openspirit.spi.logging.Logger s_log =
            com.openspirit.spi.SingletonFactory.getLogger(Access.class);

        private boolean m_needLocAttrs = false;
        private boolean m_needWellAttrs = false;
        private boolean m_needDirSAttrs = false;

        // cache of well objects
        private static MapCacheWithTimeout<String, $fileinputname$> s_cache = new MapCacheWithTimeout<String, $fileinputname$>();

        /**
         * Constructor.
         * 
         * @param tableConnection the table connection.
         */
        public Access(Petra3TableConnection tableConnection) {
            super(tableConnection);

            s_log.debug("Entered constructor()");
        }
        
        /**
         * @see com.openspirit.plugin.data.petra.v3.mapped.well.PetraReader#getTable()
         * {@inheritDoc}
         */
        @Override
        protected String getTable() {
            return TABLE;
        }

        /**
         * @see com.openspirit.plugin.data.petra.v3.mapped.well.PetraReader#getSelectColumns()
         * {@inheritDoc}
         */
        @Override
        protected String[] getSelectColumns() {
            return new String[] {
                // TODO: fill in columns
            };
        }
    }
}
