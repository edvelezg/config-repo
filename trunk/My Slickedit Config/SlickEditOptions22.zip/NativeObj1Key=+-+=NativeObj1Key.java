/*========================================================================
 * - COPYRIGHT NOTICE -                                                  *
 *                                                                       *
 * (c) Copyright 2000-2016 TIBCO Software Inc. All rights reserved.      *
 * TIBCO Confidential & Proprietary                                      *
 *                                                                       *
 ========================================================================*/

package com.openspirit.plugin.data.petra.v3.mapped.petra;

import java.sql.Timestamp;

import com.openspirit.data.OspSQLException;
import com.openspirit.unit.Unit;
import com.openspirit.plugin.data.common.MapCacheWithTimeout;
import com.openspirit.plugin.data.common.QueryUtils;
import com.openspirit.plugin.data.petra.v3.mapped.*;
import com.openspirit.spi.data.table.QueryException;
import com.openspirit.spi.data.type.SetableDataValue;
import com.openspirit.unit.DoubleQuantity;
import com.openspirit.unit.DoubleQuantitySeries;

/**
 * Structure containing relevant $fileinputname$ attributes used for OSP mappings.
 */
public final class $fileinputname$ extends PetraReader<$fileinputname$> {

    private static com.openspirit.spi.logging.Logger s_log = com.openspirit.spi.SingletonFactory
        .getLogger($fileinputname$.class);

    private static MapCacheWithTimeout<Integer, $fileinputname$> s_cache = new MapCacheWithTimeout<Integer, $fileinputname$>();

    /**
     * The native entity name.
     */
    public final static String TABLE = "$fileinputname$";

    /**
     * The name of the primary key attribute.
     */
    public static final String ID = "WSN";

    // Members are named 'm_' + the petra attribute name.
    public DoubleQuantity m_surfLat;
    public DoubleQuantity m_surfLon;
    public DoubleQuantity m_surfX;
    public DoubleQuantity m_surfY;
    public String m_offshore_OCS_Number;
    public String m_offshore_OffshoreArea;
    public String m_offshore_OffshoreBlock;
    public DoubleQuantity m_botLat;
    public DoubleQuantity m_botLon;
    public DoubleQuantity m_botX;
    public DoubleQuantity m_botY;
    public Timestamp m_chgDate;
    public Integer m_wsn;

    // Maximum length of certain string attributes.
    public static final int MAX_LEN_OCS_NUMBER     = 9;
    public static final int MAX_LEN_OFFSHORE_AREA  = 5;
    public static final int MAX_LEN_OFFSHORE_BLOCK = 7;

    /**
     * Constructor.
     *
     * @param connection
     *            the connection.
     */
    public $fileinputname$(Petra3TableConnection connection) {
        super(connection);

        s_log.debug("Entered constructor()");
    }

    /**
     * @see com.openspirit.plugin.data.petra.v3.mapped.well.PetraReader#getTable()
     * {@inheritDoc}
     */
    @Override
    protected String getTable() {
        return TABLE;
    }

    /**
     * @see com.openspirit.plugin.data.petra.v3.mapped.well.PetraReader#getSelectColumns()
     * {@inheritDoc}
     */
    @Override
    protected String[] getSelectColumns() {
        return new String[] {
            "azm",
            "ChgDate",
            "DEP_units",
            "dip",
            "dipflag",
            "IsWellDeviated",
            "md",
            "numrecs",
            "osp_DEP_units",
            "osp_XY_units",
            "Remarks",
            "SurveyRotated",
            "tvd",
            "WSN",
            "xoff",
            "XY_units",
            "yoff"
        };
    }

    /**
     * @see com.openspirit.plugin.data.petra.v3.mapped.PetraReader#createPetraObject(
     *      com.openspirit.spi.data.type.SetableDataValue[])
     * {@inheritDoc}
     */
    @Override
    protected $fileinputname$ createPetraObject(SetableDataValue[] dataValues) {
    	$fileinputname$ petra = new $fileinputname$(petra3TableConnection());

        try {
            int idx = 0;  // WARNING: Must be in same order as the above select columns
            if (isFetchedAttribute("azm"))              {  petra.m_azm = doubleQtySeries(dataValues[idx++]);            }
            if (isFetchedAttribute("ChgDate"))          {  petra.m_chgDate = (Timestamp) dataValues[idx++].getObject(); }
            if (isFetchedAttribute("DEP_units"))        {  petra.m_dEP_units = dataValues[idx++].getInt();              }
            if (isFetchedAttribute("dip"))              {  petra.m_dip = doubleQtySeries(dataValues[idx++]);            }
            if (isFetchedAttribute("dipflag"))          {  petra.m_dipflag = dataValues[idx++].getInt();                }
            if (isFetchedAttribute("IsWellDeviated"))   {  petra.m_isWellDeviated = dataValues[idx++].getInt();         }
            if (isFetchedAttribute("md"))               {  petra.m_md = doubleQtySeries(dataValues[idx++]);             }
            if (isFetchedAttribute("numrecs"))          {  petra.m_numrecs = dataValues[idx++].getInt();                }
            if (isFetchedAttribute("osp_DEP_units"))    {  petra.m_osp_DEP_units = dataValues[idx++].getUnit();  }
            if (isFetchedAttribute("osp_XY_units"))     {  petra.m_osp_XY_units = dataValues[idx++].getUnit();   }
            if (isFetchedAttribute("Remarks"))          {  petra.m_remarks = dataValues[idx++].getString();             }
            if (isFetchedAttribute("SurveyRotated"))    {  petra.m_surveyRotated = dataValues[idx++].getInt();          }
            if (isFetchedAttribute("tvd"))              {  petra.m_tvd = doubleQtySeries(dataValues[idx++]);            }
            if (isFetchedAttribute("WSN"))              {  petra.m_wsn = dataValues[idx++].getInt();                    }
            if (isFetchedAttribute("xoff"))             {  petra.m_xoff = doubleQtySeries(dataValues[idx++]);           }
            if (isFetchedAttribute("XY_units"))         {  petra.m_xY_units = dataValues[idx++].getInt();               }
            if (isFetchedAttribute("yoff"))             {  petra.m_yoff = doubleQtySeries(dataValues[idx++]);           }
        }
        catch (com.openspirit.InvalidTypeException e) {
            s_log.severe("Programming error: Caught InvalidTypeException: " + e.getDescription()
                    + ", details: " + e.getDetails(), e);
        }
        return petra;
    }

    /**
     * @see com.openspirit.plugin.data.petra.v3.mapped.PetraAccessCache#clearCache()
     *      {@inheritDoc}
     */
    protected void clearCache() {
        s_log.debug("Clearing cache for '" + TABLE + "'.");

        s_cache.clearCache();
    }

    /**
     * Clears the specified element from the cache.
     *
     * @param wsn the $fileinputname$ id to clear.
     */
    @SuppressWarnings("boxing")
    private static void clear(int wsn) {
        try {
            s_cache.writeLock();

            s_cache.getMap().remove(wsn);
        }
        finally {
            s_cache.releaseLock();
        }

    }

    /**
     * Returns the $fileinputname$ instance with the specified key. 
     *
     * @param wsn the key to find.
     * @return the instance or null.
     */
    public $fileinputname$ get(int wsn) {
       s_log.debug("Getting element from " + TABLE + " with wsn " + wsn);

       $fileinputname$ result = null;

       // Try getting the key from the cache.
       try {
          s_cache.readLock();

          result = s_cache.getMap().get(wsn);
        }
        finally {
          s_cache.releaseLock();
       }

       // The requested key is not in the cache, read and return it.
       if (result == null) {
          try {
//             String wsn = wsn.substring(0,  wsn.indexOf(KEY_SEPARATOR));

             s_cache.writeLock();

             read("WSN = " + wsn);

             // Traverse all results from the read with next() call and save them in the cache.
             while ((result = next()) != null) {
                s_cache.getMap().put(result.m_wsn, result);
             }

             // Set result to the cache result.
             result = s_cache.getMap().get(wsn);

          } catch (OspSQLException e) {
             s_log.severe("Caught OspSQLException: " + e.getMessage(), e);
            }
            finally {
             close();
             s_cache.releaseLock();
          }
       }

       return result;
    }

    /**
     * Reads the $fileinputname$ ids with the wsn specified in the m_idList list.
     *
     * @param wsnList
     * @return java.util.List<Integer> ids matching the specified filter..
     */
    public void readByWsns(java.util.Collection<Integer> wsnList) {
        s_log.debug("Entered readByWsns()");
        
        read(QueryUtils.inClauseInts(ID, wsnList));
    }


    /**
     * Inserts the specified row in the $fileinputname$ table with the specified values.
     *
     * @param var$fileinputname$ the object holding the insert values.
     * @return the new id.
     * @throws com.openspirit.spi.data.table.QueryException if the insert fails.
     */
    public int insert($fileinputname$ var$fileinputname$) throws QueryException {
        s_log.debug("Entered insert()");

        int newWsn = -1;

        com.openspirit.spi.data.QueryExecutor executor = null;
        com.openspirit.spi.data.QueryResult result = null;

        try {
            final String[] insertCols = new String[] {
                  "azm"
                 ,"DEP_units"
                 ,"dip"
                 ,"dipflag"
                 ,"IsWellDeviated"
                 ,"md"
                 ,"numrecs"
                 ,"Remarks"
                 ,"SurveyRotated"
                 ,"tvd"
                 ,"WSN"
                 ,"xoff"
                 ,"XY_units"
                 ,"yoff"
            };

            final String sql = formatInsertStatement(TABLE, insertCols);

            com.openspirit.spi.data.QueryParameters params = queryParams(insertCols.length);

            int idx = 1;
            params.setParameterValue(idx++, sdvu().doubleQtySeries(var$fileinputname$.m_azm));
            params.setParameterValue(idx++, sdvu().intVal(var$fileinputname$.m_dEP_units));
            params.setParameterValue(idx++, sdvu().doubleQtySeries(var$fileinputname$.m_dip));
            params.setParameterValue(idx++, sdvu().intVal(var$fileinputname$.m_dipflag));
            params.setParameterValue(idx++, sdvu().intVal(var$fileinputname$.m_isWellDeviated));
            params.setParameterValue(idx++, sdvu().doubleQtySeries(var$fileinputname$.m_md));
            params.setParameterValue(idx++, sdvu().intVal(var$fileinputname$.m_numrecs));
            params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_remarks));
            params.setParameterValue(idx++, sdvu().intVal(var$fileinputname$.m_surveyRotated));
            params.setParameterValue(idx++, sdvu().doubleQtySeries(var$fileinputname$.m_tvd));
            params.setParameterValue(idx++, sdvu().intVal(var$fileinputname$.m_wsn));
            params.setParameterValue(idx++, sdvu().doubleQtySeries(var$fileinputname$.m_xoff));
            params.setParameterValue(idx++, sdvu().intVal(var$fileinputname$.m_xY_units));
            params.setParameterValue(idx++, sdvu().doubleQtySeries(var$fileinputname$.m_yoff));

            s_log.debug("Native SQL query: " + sql.toString());
            executor = nativeQueryExecutor(sql);
            result = executor.executeQuery(params);

            if (result.next()) {
                // There is only 1 row in the result set.
                SetableDataValue[] sdv = result.getDataValuesSet().getSetableDataValues();
                com.openspirit.spi.data.DataKey nativeKey = spiDataKey(sdv[0]);
                newWsn = nativeKey.getKeyValues()[0].getInt();
            }

            s_log.debug("Inserted row into " + TABLE + " id=" + newWsn);
        }
        catch (com.openspirit.BadArgumentsException e) {
            s_log.severe("Programming error: Caught BadArgumentsException: " + e.getMessage(), e);
            throw new com.openspirit.OspRuntimeException("Programming error: " + e.getDescription(), e);
        }
        catch (com.openspirit.data.OspSQLException e) {
            s_log.severe("Caught OspSQLException: " + e.getMessage(), e);
            Petra3Utils.throwQueryException(e);
        }
        catch (com.openspirit.InvalidTypeException e) {
            s_log.severe("Programming error: Caught InvalidTypeException: " + e.getMessage(), e);
            throw new com.openspirit.OspRuntimeException("Programming error: " + e.getDescription(), e);
        }
        catch (Exception e) {
            s_log.severe("Caught Exception: " + e.getMessage() + ", ", e);
            e.printStackTrace();
            throw new com.openspirit.OspRuntimeException("Caught Exception: " + e.getMessage(), e);
        }
        finally {
            QueryUtils.close(result, executor);
        }

        clear(var$fileinputname$.m_wsn);
        s_log.debug("Leaving insert(), new var$fileinputname$ wsn id=" + newWsn);
        return newWsn;
    }

    //---------------------------------------------------------------------------------------------------------------------------
    /**
     * Updates the specified row in the table with the specified values.
     * @param var$fileinputname$ the object holding the update values..
     * @throws com.openspirit.spi.data.table.QueryException if the update fails.
     */
    public void update($fileinputname$ var$fileinputname$) throws QueryException {
        s_log.debug("Entered update()");

        //String key = makeKey(m_stratColumn, m_unitName);
        com.openspirit.spi.data.QueryExecutor executor = null;
        com.openspirit.spi.data.QueryResult result = null;

        try {

            final String[] updateCols = new String[] {
                  "azm"
                 ,"DEP_units"
                 ,"dip"
                 ,"dipflag"
                 ,"IsWellDeviated"
                 ,"md"
                 ,"numrecs"
                 ,"Remarks"
                 ,"SurveyRotated"
                 ,"tvd"
                 ,"WSN"
                 ,"xoff"
                 ,"XY_units"
                 ,"yoff"
            };

            final String sql = formatUpdateStatement(TABLE, updateCols)
                + " WHERE " + ID + " = " + var$fileinputname$.m_wsn;

            com.openspirit.spi.data.QueryParameters params = queryParams(updateCols.length);
            int idx = 1;
            params.setParameterValue(idx++, sdvu().doubleQtySeries(var$fileinputname$.m_azm));
            params.setParameterValue(idx++, sdvu().intVal(var$fileinputname$.m_dEP_units));
            params.setParameterValue(idx++, sdvu().doubleQtySeries(var$fileinputname$.m_dip));
            params.setParameterValue(idx++, sdvu().intVal(var$fileinputname$.m_dipflag));
            params.setParameterValue(idx++, sdvu().intVal(var$fileinputname$.m_isWellDeviated));
            params.setParameterValue(idx++, sdvu().doubleQtySeries(var$fileinputname$.m_md));
            params.setParameterValue(idx++, sdvu().intVal(var$fileinputname$.m_numrecs));
            params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_remarks));
            params.setParameterValue(idx++, sdvu().intVal(var$fileinputname$.m_surveyRotated));
            params.setParameterValue(idx++, sdvu().doubleQtySeries(var$fileinputname$.m_tvd));
            params.setParameterValue(idx++, sdvu().intVal(var$fileinputname$.m_wsn));
            params.setParameterValue(idx++, sdvu().doubleQtySeries(var$fileinputname$.m_xoff));
            params.setParameterValue(idx++, sdvu().intVal(var$fileinputname$.m_xY_units));
            params.setParameterValue(idx++, sdvu().doubleQtySeries(var$fileinputname$.m_yoff));

            s_log.debug("Native SQL Statement: " + sql);
            executor = nativeQueryExecutor(sql);
            result = executor.executeQuery(params);

            s_log.debug("Updated " + TABLE + " id=" + var$fileinputname$.m_wsn);
        }
        catch (com.openspirit.data.OspSQLException e) {
            s_log.severe("Caught OspSQLException: " + e.getMessage(), e);
            Petra3Utils.throwQueryException(e);
        }
        catch (com.openspirit.BadArgumentsException e) {
            s_log.severe("Programming error: Caught BadArgumentsException: " + e.getMessage(), e);
            throw new com.openspirit.OspRuntimeException("Programming error: " + e.getDescription(), e);
        }
        finally {
            QueryUtils.close(result, executor);
        }

        s_log.debug("Removing updated element from the cache");
        clear(var$fileinputname$.m_wsn);

        s_log.debug("Leaving update().");
    }


    /**
     * Deletes the specified row from the $fileinputname$ table.
     *
     * @param wsn the $fileinputname$ wsn.
     */
    public void delete(Integer wsn) throws com.openspirit.spi.data.table.QueryException {
        s_log.debug("Entered delete(), wsn=" + wsn);

        com.openspirit.spi.data.QueryExecutor executor = null;
        com.openspirit.spi.data.QueryResult result = null;

        try {
            final String sql = "DELETE FROM " + TABLE + " "
                + "WHERE " + ID + " = " + wsn.toString();

            executor = nativeQueryExecutor(sql);
            result = executor.executeQuery(null);

            s_log.debug("Deleted " + TABLE + " wsn=" + wsn);
        }
        catch (com.openspirit.data.OspSQLException e) {
            s_log.severe("Caught OspSQLException: " + e.getMessage(), e);

            Petra3Utils.throwQueryException(e);
        }
        finally {
            QueryUtils.close(result, executor);
        }

        s_log.debug("Removing deleted element from the cache");
//        clear(wsn);
        s_log.debug("Leaving delete().");
    }

    /**
     * Sets what related attributes need to be fetched during read.
     */
    public void setRelatedAttributesToFetch () {
    }
    
    /**
     * @see com.openspirit.plugin.data.petra.v3.mapped.petra.PetraReader#fetchRelatedAttributes()
     * {@inheritDoc}
     */
    @Override
    protected void fetchRelatedAttributes() {
    }
}
