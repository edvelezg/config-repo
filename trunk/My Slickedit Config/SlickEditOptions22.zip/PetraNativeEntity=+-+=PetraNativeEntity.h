/*========================================================================
 * - COPYRIGHT NOTICE -                                                  *
 *                                                                       *
 * Copyright 2000-2016 OpenSpirit Corporation                            *
 *                                                                       *
 * The information contained herein and which follows is proprietary     *
 * information and is the property of OpenSpirit Corporation. This       *
 * information is not to be divulged, released, copied, reproduced,      *
 * or conveyed to unauthorized personnel, companies, or other            *
 * institutions without the direct and expressed approval in writing     *
 * of OpenSpirit Corporation.                                            *
 *                                                                       *
 ========================================================================*/

#ifndef _osp_plugin_data_petra_$fileinputname$_h
#define _osp_plugin_data_petra_$fileinputname$_h _osp_plugin_data_petra_$fileinputname$_h_

#include <osp/plugin/data/petra/petra.h>
#include <osp/data/data.h>
#include <osp/spi/data/table/table.h>
#include <osp/spi/data/type/type.h>

#include <vector>

/** 
 * This class represents a specific native entity type, not single entity.
 */
class osp::plugin::data::petra::$fileinputname$: osp::plugin::data::petra::PetraEntity
{
public:

   /**
    * Constructor.
    */
   $fileinputname$(const osp::metamodel::EntityDefinition &entityDef,
                const osp::data::ProjectDefinition &projectDef,
                const osp::spi::data::table::TableConnection &connection);

   /**
    * Destructor.
    */
   virtual ~$fileinputname$();

   // Virtual methods that each type of entities needs to implement

   virtual void executeQuery();

   virtual long getRowCount() const;

   virtual bool next();

   // Read the current row
   virtual void readRow(const osp::vector<osp::metamodel::AttributeDefinition> &selectColumns,
                        osp::vector<osp::spi::data::type::SetableDataValue> &selectColumnValues) const;

   virtual void updateRow(const osp::vector<osp::metamodel::AttributeDefinition> &updateColumns,
                          const osp::vector<osp::spi::data::type::DataValue> &updateColumnValues);

   virtual osp::spi::data::DataKey insertRow(const osp::spi::data::table::Table &table,
                                             const osp::vector<osp::metamodel::AttributeDefinition> &columns,
                                             const osp::vector<osp::spi::data::type::DataValue> &columnValues);

   virtual void deleteRow();

private:

   // Static data members.
   static osp::spi::logging::Logger s_log;

   std::vector<int> m_entList;
   int m_entLen;
   int m_entIndex;

}; // End class osp::plugin::data::petra::$fileinputname$

#endif // _osp_plugin_data_petra_$fileinputname$_h
