/*========================================================================
* - COPYRIGHT NOTICE - *
* *
* (c) Copyright 2000-2015 TIBCO Software Inc. All rights reserved. *
* TIBCO Confidential & Proprietary *
* *
========================================================================*/

#include <Windows.h>

#include "PetraLibEx.h"
#include "$LibObj$.h"

/*
* Local Types
*/
//typedef int(__stdcall * PETRA_PayData)(int wsn);

typedef int (__stdcall *PETRA_$LibObj$Get_Proc)(int pid, PETRA_$LibObj$ *payDataDef);
typedef int (__stdcall *PETRA_$LibObj$Add_Proc)(PETRA_$LibObj$ *payDataDef);
typedef int (__stdcall *PETRA_$LibObj$Put_Proc)(int pid, PETRA_$LibObj$ *payDataDef);
typedef int (__stdcall *PETRA_$LibObj$InitStruct_Proc)(PETRA_$LibObj$ *payDataDef);

typedef int (__stdcall *PETRA_PayDataGet_Proc)(int mode, int recid, int wsn, int pid, PETRA_PayData *payDataRec);
typedef int (__stdcall *PETRA_PayDataPut_Proc)(int wsn, int pid, PETRA_PayData *payDataRec);
typedef int (__stdcall *PETRA_PayDataDelete_Proc)(int wsn, int pid, int recid);
typedef int (__stdcall *PETRA_PayDataInitStruct_Proc)(PETRA_PayData *payDataRec);

//	- Functions
static PETRA_$LibObj$Get_Proc PETRA_$LibObj$Get_FnctP = NULL;
static PETRA_$LibObj$Add_Proc PETRA_$LibObj$Add_FnctP = NULL;
static PETRA_$LibObj$Put_Proc PETRA_$LibObj$Put_FnctP = NULL;
static PETRA_$LibObj$InitStruct_Proc PETRA_$LibObj$InitStruct_FnctP = NULL;

static PETRA_PayDataGet_Proc PETRA_PayDataGet_FnctP = NULL;
static PETRA_PayDataPut_Proc PETRA_PayDataPut_FnctP = NULL;
static PETRA_PayDataDelete_Proc PETRA_PayDataDelete_FnctP = NULL;
static PETRA_PayDataInitStruct_Proc PETRA_PayDataInitStruct_FnctP = NULL;

void PETRA_PayData_Init(HINSTANCE petraLibInstH)
{
   PETRA_$LibObj$Get_FnctP = (PETRA_$LibObj$Get_Proc)LoadProc(petraLibInstH, "PETRA_$LibObj$Get");
   PETRA_$LibObj$Add_FnctP = (PETRA_$LibObj$Add_Proc)LoadProc(petraLibInstH, "PETRA_$LibObj$Add");
   PETRA_$LibObj$Put_FnctP = (PETRA_$LibObj$Put_Proc)LoadProc(petraLibInstH, "PETRA_$LibObj$Put");
   PETRA_$LibObj$InitStruct_FnctP = (PETRA_$LibObj$InitStruct_Proc)LoadProc(petraLibInstH, "PETRA_$LibObj$InitStruct");

   PETRA_PayDataGet_FnctP = (PETRA_PayDataGet_Proc)LoadProc(petraLibInstH, "PETRA_PayDataGet");
   PETRA_PayDataPut_FnctP = (PETRA_PayDataPut_Proc)LoadProc(petraLibInstH, "PETRA_PayDataPut");
   PETRA_PayDataDelete_FnctP = (PETRA_PayDataDelete_Proc)LoadProc(petraLibInstH, "PETRA_PayDataDeleteRec");
   PETRA_PayDataInitStruct_FnctP = (PETRA_PayDataInitStruct_Proc)LoadProc(petraLibInstH, "PETRA_PayDataInitStruct");
}

// Implementation

int PETRA_$LibObj$Get(int pid, PETRA_$LibObj$ *payDataDef) {
   return PETRA_$LibObj$Get_FnctP(pid, payDataDef);
}

int PETRA_$LibObj$Add(PETRA_$LibObj$ *payDataDef) {
   return PETRA_$LibObj$Add_FnctP(payDataDef);
}

int PETRA_$LibObj$Put(int pid, PETRA_$LibObj$ *payDataDef) {
   return PETRA_$LibObj$Put_FnctP(pid,payDataDef);
}

int PETRA_$LibObj$InitStruct(PETRA_$LibObj$ *payDataDef) {
   return PETRA_$LibObj$InitStruct_FnctP(payDataDef);
}

int PETRA_PayDataGet(int mode, int recid, int wsn, int pid, PETRA_PayData *payDataRec) {
   return PETRA_PayDataGet_FnctP(mode,recid,wsn,pid,payDataRec);
}

int PETRA_PayDataPut(int wsn, int pid, PETRA_PayData *payDataRec) {
   return PETRA_PayDataPut_FnctP(wsn,pid,payDataRec);
}

int PETRA_PayDataDelete(int wsn, int pid, int recid) {
   return PETRA_PayDataDelete_FnctP(wsn,pid,recid);
}

int PETRA_PayDataInitStruct(PETRA_PayData *payDataRec) {
   return PETRA_PayDataInitStruct_FnctP(payDataRec);
}

bool isPaySupportedByPetra()
{
    // function 'PETRA_$LibObj$InitStruct_FnctP' does not exist for Petra versions prior to v3.2.
    return (PETRA_$LibObj$InitStruct_FnctP != NULL) && (PETRA_$LibObj$Get_FnctP != NULL);
}


//PETRA_PayData* PETRA_GetPayData(int wsn, int recid) {
// int entityCount = PETRA_PayDataCount(wsn);
// if (entityCount <= 0) {
// return NULL;
// }
// PETRA_PayData* pEntity = new PETRA_PayData();
// int res = PETRA_SUCCESS;
//
// for (int i = 0; i < entityCount; i++) {
// res = PETRA_PayDataInitStruct(pEntity);
// if (res != PETRA_SUCCESS) {
// continue;
// }
// int mode = i == 0 ? PETRA_GET_FIRST : PETRA_GET_NEXT;
// res = PETRA_PayDataGet(mode, wsn, pEntity);
// if (res != PETRA_SUCCESS) {
// continue;
// }
// if (pEntity->recid == recid) {
// return pEntity;
// }
// }
// // not found
// return NULL;
//}
