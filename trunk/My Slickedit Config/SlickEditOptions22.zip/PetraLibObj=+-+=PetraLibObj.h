// $LibObj$.h

#pragma once
#ifdef __cplusplus
extern "C" {
#endif

/*
 * Types
 */
#pragma pack(push)
#pragma pack(1)

typedef char PetrisDate[10];

/*
   { Pay Data }
   pTPAYDATADEF = ^TPAYDATADEF;
   TPAYDATADEF = packed record
   pid : integer;
   //flags : integer;
   color : integer;
   zid   : integer;
   fid   : integer;
   numcut : integer;
   cutoffs : array[0..9] of double;
   adddate : TPetrisDate;
   chgdate : TPetrisDate;
   pattern : integer;
   patscale : double;
   name  : array[0..32] of AnsiChar;
   source : array[0..32] of AnsiChar;
   desc   : array[0..80] of AnsiChar;
   remark : TRemark;
   end;
*/
   typedef struct {
      int                  pid;
      //int              flags;
      int                color;
      int                  zid;
      int                  fid;
      int               numcut;
      double        cutoffs[10];
      PetrisDate       adddate;
      PetrisDate       chgdate;
      int              pattern;
      double          patscale;
      char            name[33];
      char          source[33];
      char           _desc[81];
      Remark            remark;
   } PETRA_$LibObj$;

/*
   pTPAYDATAREC = ^TPAYDATAREC;
   TPAYDATAREC = packed record
   wsn   : integer;
   pid   : integer;
   //flags  : integer;
   recid  : integer;
   iunits : integer;
   ign   : integer;
   paynum : integer;
   cutoffpos : integer;
   top   : double;
   base   : double;
   end;
*/
   typedef struct {
      int                  wsn;
      int                  pid;
//     int               flags;
      int                recid;
      int               iunits;
      int                  ign;
      int               paynum;
      int            cutoffpos;
      double               top;
      double              base;
   } PETRA_PayData;

#pragma pack(pop)

   /*
   * Functions
   */
   void PETRA_PayData_Init(HINSTANCE petraLibInstH);

   int PETRA_$LibObj$Get(int pid, PETRA_$LibObj$* payDataDef);
   int PETRA_$LibObj$Add(PETRA_$LibObj$* payDataDef);
   int PETRA_$LibObj$Put(int pid, PETRA_$LibObj$* payDataDef);
   int PETRA_$LibObj$InitStruct(PETRA_$LibObj$* payDataDef);

   int PETRA_PayDataGet(int mode, int  recid, int  wsn, int  pid, PETRA_PayData* payDataRec);
   int PETRA_PayDataPut(int wsn, int  pid, PETRA_PayData* payDataRec);
   int PETRA_PayDataDelete(int wsn, int  pid, int  recid);
   int PETRA_PayDataInitStruct(PETRA_PayData* payDataRec);
   bool isPaySupportedByPetra();

   // Added as a convenience method. Get PayData by wsn and pid
   // Return a PayData record if successful; NULL otherwise
   PETRA_PayData* PETRA_GetPayData(int wsn, int pid);

#ifdef __cplusplus
}
#endif
