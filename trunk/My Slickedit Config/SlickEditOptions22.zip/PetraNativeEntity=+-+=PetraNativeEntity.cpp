/*========================================================================
 * - COPYRIGHT NOTICE -                                                  *
 *                                                                       *
 * Copyright 2000-2016 OpenSpirit Corporation                            *
 *                                                                       *
 * The information contained herein and which follows is proprietary     *
 * information and is the property of OpenSpirit Corporation. This       *
 * information is not to be divulged, released, copied, reproduced,      *
 * or conveyed to unauthorized personnel, companies, or other            *
 * institutions without the direct and expressed approval in writing     *
 * of OpenSpirit Corporation.                                            *
 *                                                                       *
 ========================================================================*/

#include <osp/plugin/data/petra/entities/$fileinputname$.h>
#include <osp/plugin/data/petra/petraLib/PetraLibEx.h>
#include <osp/plugin/data/petra/petraLib/$LibObj$.h>
#include <osp/spi/data/table/SimpleConstraintVisitor.h>

osp::spi::logging::Logger
osp::plugin::data::petra::$fileinputname$::s_log(
   osp::spi::SingletonFactory::getLogger("osp::plugin::data::petra::$fileinputname$"));

//=========================================================================================
osp::plugin::data::petra::$fileinputname$::$fileinputname$(
	const osp::metamodel::EntityDefinition& entityDef,
	const osp::data::ProjectDefinition& projectDef,
    const osp::spi::data::table::TableConnection& connection) 
      :
      PetraEntity(entityDef, projectDef, connection)
//=========================================================================================
{
	m_entList.clear();
} 

//=========================================================================================
osp::plugin::data::petra::$fileinputname$::~$fileinputname$() 
//=========================================================================================
{ 
	m_entList.clear();
}

//=========================================================================================
void osp::plugin::data::petra::$fileinputname$::executeQuery()
//=========================================================================================
{
   if (s_log.isDetailEnabled()) {
      s_log.debug("Entered $fileinputname$::executeQuery()");
   }

   m_entList.clear();

   boolean constraintFlag = false;
   osp::vector<osp::Integer> idList;
   m_entLen = 0;

   if (!m_selectConstraint.isNull()) {
      idList = m_visitor.getIntegerList("$pk_id$");
   }

   if (idList.size() > 0) {
      constraintFlag = true;
      m_entList.resize(idList.size());
      for (unsigned int i = 0; i < idList.size(); i++) {
         PETRA_$NativeObj$ entity;
         int res = PETRA_$NativeObj$Get(idList[i], &entity);
         if (res == PETRA_SUCCESS) {
            m_entList[m_entLen] = idList[i];
            m_entLen++;
         }
      }
   }

   if (!constraintFlag) {
      int res = PETRA_SUCCESS;
      size_t id = 1;
      while (res == PETRA_SUCCESS) {
         PETRA_$NativeObj$ pEntity;
         int res = PETRA_$NativeObj$Get(id, &pEntity);

         if (res == PETRA_FAIL) break;

         m_entList.push_back(id++);
         m_entLen++;
      }
   }

   m_entIndex = -1;
}

//=========================================================================================
long osp::plugin::data::petra::$fileinputname$::getRowCount() const
//=========================================================================================
{
    return m_entLen;
}

//=========================================================================================
osp::spi::data::DataKey
osp::plugin::data::petra::$fileinputname$::insertRow(
   const osp::spi::data::table::Table &table,
   const osp::vector<osp::metamodel::AttributeDefinition> &insertColumns,
   const osp::vector<osp::spi::data::type::DataValue> &insertColumnValues)
//=========================================================================================
{
   if (s_log.isDetailEnabled()) {
      s_log.debug("Entered $fileinputname$::insertRow()");
   }

   PETRA_$NativeObj$ pEntity;
   int res = PETRA_$NativeObj$InitStruct(&pEntity);

   if (res != PETRA_SUCCESS) {
       throw osp::spi::data::table::QueryException(
           osp::spi::data::QueryExceptionType::GENERAL_DATA_EXCEPTION,
           std::string("PETRA_$NativeObj$InitStruct() returned ") + PETRA_ErrorMsg(res));
   }

   for (unsigned int colIdx = 0; colIdx < insertColumns.size(); colIdx++) {
       const osp::metamodel::AttributeDefinition& attrDef = insertColumns[colIdx];
       const osp::spi::data::type::DataValue& valueToSet = insertColumnValues[colIdx];
       setAttributeFromDataValue(attrDef, valueToSet, &pEntity);
   }
    
   // The return value of PETRA_$NativeObj$Add() is the new $pk_id$
   res = PETRA_$NativeObj$Add(&pEntity);
   if (res != PETRA_SUCCESS) {
       throw osp::spi::data::table::QueryException(
           osp::spi::data::QueryExceptionType::GENERAL_DATA_EXCEPTION,
           std::string("PETRA_$NativeObj$Add() returned ") + PETRA_ErrorMsg(res));
   }

   res = PETRA_$NativeObj$Get(pEntity.$pk_id$, &pEntity);

   if (res != PETRA_SUCCESS) {
      throw osp::spi::data::table::QueryException(
         osp::spi::data::QueryExceptionType::GENERAL_DATA_EXCEPTION,
         std::string("PETRA_$NativeObj$Get() returned ") + PETRA_ErrorMsg(res));
   }

   // Get the DataKey for the newly inserted row.
   osp::spi::data::DataKey primaryKey = getDataKey(table, &pEntity);
   return primaryKey;
}

//=========================================================================================
void osp::plugin::data::petra::$fileinputname$::updateRow(
        const osp::vector<osp::metamodel::AttributeDefinition>& updateColumns,
        const osp::vector<osp::spi::data::type::DataValue>& updateColumnValues)
//=========================================================================================
{
   if (s_log.isDetailEnabled()) {
      s_log.debug("Entered $fileinputname$::updateRow()");
   }

   PETRA_$NativeObj$ pEntity;
   int res = PETRA_$NativeObj$Get(m_entList[m_entIndex], &pEntity);

   if (res != PETRA_SUCCESS) {
      throw osp::spi::data::table::QueryException(
         osp::spi::data::QueryExceptionType::GENERAL_DATA_EXCEPTION,
         std::string("PETRA_$NativeObj$Get() returned ") + PETRA_ErrorMsg(res));
   }

   for (unsigned int colIdx = 0; colIdx < updateColumns.size(); colIdx++) {
      const osp::metamodel::AttributeDefinition &attrDef = updateColumns[colIdx];
      const osp::spi::data::type::DataValue &valueToSet = updateColumnValues[colIdx];
      setAttributeFromDataValue(attrDef, valueToSet, &pEntity);
   }

   // Strange behaviour in devkit put method does not return an error code but the $pk_id$.
   res = PETRA_$NativeObj$Put(m_entList[m_entIndex], &pEntity);

   if (res < PETRA_SUCCESS) {
      throw osp::spi::data::table::QueryException(
         osp::spi::data::QueryExceptionType::GENERAL_DATA_EXCEPTION,
         std::string("PETRA_$NativeObj$Put() returned ") + PETRA_ErrorMsg(res));
   }
}
//=========================================================================================
void osp::plugin::data::petra::$fileinputname$::deleteRow()
//=========================================================================================
{
   //throw osp::OspRuntimeException("Deleting IntDataDef is not supported.");

   if (s_log.isDetailEnabled()) {
      s_log.debug("Entered $fileinputname$::deleteRow()");
   }

   int res = PETRA_$NativeObj$Delete(m_entList[m_entIndex]);
   if (res != PETRA_SUCCESS) {
      throw osp::spi::data::table::QueryException(
         osp::spi::data::QueryExceptionType::GENERAL_DATA_EXCEPTION,
         std::string("PETRA_$NativeObj$Delete() returned ")
         + PETRA_ErrorMsg(res));
   }
}

//=========================================================================================
void osp::plugin::data::petra::$fileinputname$::readRow(
        const osp::vector<osp::metamodel::AttributeDefinition>& selectColumns,
        osp::vector<osp::spi::data::type::SetableDataValue>& selectColumnValues) const
//=========================================================================================
{
   if (s_log.isDetailEnabled()) {
      s_log.debug("Entered $fileinputname$::readRow()");
   }

   PETRA_$NativeObj$ pEntity;
   int res = PETRA_$NativeObj$Get(m_entList[m_entIndex], &pEntity);

   if (res != PETRA_SUCCESS) {
      throw osp::spi::data::table::QueryException(
         osp::spi::data::QueryExceptionType::GENERAL_DATA_EXCEPTION,
         std::string("PETRA_$NativeObj$Get() returned ") + PETRA_ErrorMsg(res));
   }

   for (unsigned int colIdx = 0; colIdx < selectColumns.size(); colIdx++) {
      std::string attrName = selectColumns[colIdx].getName();
      setDataValueFromAttribute(&pEntity, attrName, selectColumnValues[colIdx]);
   }
}

//=========================================================================================
bool osp::plugin::data::petra::$fileinputname$::next()
//=========================================================================================
{
   auto hasNext = ++m_entIndex < m_entLen;
   return hasNext;
}

