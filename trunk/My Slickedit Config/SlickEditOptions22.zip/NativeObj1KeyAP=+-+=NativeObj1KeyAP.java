/*========================================================================
 * - COPYRIGHT NOTICE -                                                  *
 *                                                                       *
 * (c) Copyright 2000-2016 TIBCO Software Inc. All rights reserved.      *
 * TIBCO Confidential & Proprietary                                      *
 *                                                                       *
 ========================================================================*/

package com.openspirit.plugin.data.petra.v3.mapped.petra;

import java.sql.Timestamp;
import java.util.Map;
import com.openspirit.data.OspSQLException;
import com.openspirit.plugin.data.common.MapCacheWithTimeout;
import com.openspirit.plugin.data.common.QueryUtils;
import com.openspirit.plugin.data.petra.v3.mapped.Petra3TableConnection;
import com.openspirit.plugin.data.petra.v3.mapped.well.PetraDirectionalSurvey;
import com.openspirit.spi.data.table.QueryException;
import com.openspirit.spi.data.type.SetableDataValue;
import com.openspirit.unit.DoubleQuantity;

/**
 * Class implementation for the $fileinputname$ table.
 */
public final class $fileinputname$ {

    /**
     * The native entity name.
     */
    public final static String TABLE = "$fileinputname$";

    /**
     * The name of the primary key attribute.
     */
    public static final String ID = "$1key$";

    /**
     * The identifier type of the identifier from the associated OpenSpirit entity.
     */
    public static final String IDENTIFIER_TYPE = "UWI";
    public static final String TOTAL_DEPTH_TYPE = "TotalDepth";

    // Members are named 'm_' + the petra attribute name. 
    public  Timestamp       m_abandoned;
    public  Timestamp       m_chgDate;
    public  Timestamp       m_completion;
    public  String          m_county;
    public  DoubleQuantity  m_datum;
    public  String          m_datumCode;
    public  String          m_fieldName;
    public  String          m_fMatTD;
    public  String          m_histOper;
    public  String          m_leaseName;
    public  String          m_leaseNbr;
    public  String          m_operator;
    public  DoubleQuantity  m_osp_ELEV_DF;
    public  DoubleQuantity  m_osp_ELEV_KB;
    public  DoubleQuantity  m_osp_ELEV_SEIS;
    public  DoubleQuantity  m_osp_ELEV_GR;
    public  Timestamp       m_permit;
    public  String          m_prodFM;
    public  String          m_remarks;
    public  Timestamp       m_rig;
    public  Timestamp       m_spud;
    public  String          m_state;
    public  String          m_symCode;
    public  DoubleQuantity  m_tD;
    public  String          m_uwi;
    public  String          m_wellLabel;
    public  String          m_wellName;
    public  String          m_wellNumber;
    public  $1key_t$        m_$1key$;
    
    // Related / Calculated attributes
    // Native object $fileinputname$ 
    public java.util.List<FormationTop> m_petraPicks = null;
    public java.util.List<OSP_$fileinputname$Zone> m_wellZones = null;
    public java.util.List<$fileinputname$Log> m_wellLogs = null;
    public Loc m_wellLoc = null;
    public DirSrvHdr m_dirSrvHdr = null;

    // Maximum lengths of some important string attributes
    public static final int MAX_LEN_UWI         = 20;
    public static final int MAX_LEN_WELL_LABEL  = 32;
    public static final int MAX_LEN_WELL_NUMBER = 20;
    public static final int MAX_LEN_WELL_NAME   = 255;
    public static final int MAX_LEN_REMARKS     = 40;
    public static final int MAX_LEN_SYM_CODE    = 8;
    public static final int MAX_LEN_OPERATOR    = 40;
    public static final int MAX_LEN_HIST_OPER   = 40;
    public static final int MAX_LEN_LEASE_NAME  = 40;
    public static final int MAX_LEN_LEASE_NBR   = 40;
    public static final int MAX_LEN_FIELD_NAME  = 40;
    public static final int MAX_LEN_FMAT_TD     = 20;
    public static final int MAX_LEN_PROD_FM     = 20;
    public static final int MAX_LEN_COUNTY      = 20;
    public static final int MAX_LEN_STATE       = 2;
    
    /**
     * Constructor.
     *
     * @param connection the connection.
     */
    public $fileinputname$() {
    }

    /**
     * Access class for $fileinputname$.
     */
    public static class Access extends PetraReader<$fileinputname$> {

        private static com.openspirit.spi.logging.Logger s_log =
            com.openspirit.spi.SingletonFactory.getLogger(Access.class);

        private boolean m_needLocAttrs = false;
        private boolean m_needPickAttrs = false;
        private boolean m_needZoneAttrs = false;
        private boolean m_needLogAttrs = false;
        private boolean m_needDirSAttrs = false;

        // cache of well objects
        private static MapCacheWithTimeout<Integer, $fileinputname$> s_cache = new MapCacheWithTimeout<Integer, $fileinputname$>();

        /**
         * Constructor.
         * 
         * @param tableConnection the table connection.
         */
        public Access(Petra3TableConnection tableConnection) {
            super(tableConnection);

            s_log.debug("Entered constructor()");
        }

        /**
         * @see com.openspirit.plugin.data.petra.v3.mapped.well.PetraReader#getTable()
         * {@inheritDoc}
         */
        @Override
        protected String getTable() {
            return TABLE;
        }

        /**
         * @see com.openspirit.plugin.data.petra.v3.mapped.well.PetraReader#getSelectColumns()
         * {@inheritDoc}
         */
        @Override
        protected String[] getSelectColumns() {
            return new String[] {
                "$1key$",
                "ChgDate",
                "County",
                "Completion",
                "FieldName",
                "FMatTD",
                "HistOper",
                "LeaseName",
                "LeaseNbr",
                "Operator",
                "ProdFM",
                "Remarks",
                "State",
                "SymCode",
                "uwi",
                "$fileinputname$Label",
                "$fileinputname$Name",
                "$fileinputname$Number",
                "Spud",
                "TD",
                "Datum",
                "DatumCode",
                "osp_ELEV_GR",
                "osp_ELEV_DF",
                "osp_ELEV_KB",
                "osp_ELEV_SEIS"
            };
        }

        /**
         * @see com.openspirit.plugin.data.petra.v3.mapped.well.PetraReader#createGdiObject(com.openspirit.spi.data.type.SetableDataValue[])
         * {@inheritDoc}
         */
        @Override
        protected $fileinputname$ createPetraObject(SetableDataValue[] dataValues) {
            $fileinputname$ petra = new $fileinputname$();

            try {
                int idx = 0;
                // NOTE: Sorry for the weird formatting, it is easier to read and interpret this way!
                if (isFetchedAttribute("$1key$"))           {petra.m_$1key$           = dataValues[idx++].get$1key_t$();}
                if (isFetchedAttribute("ChgDate"))       {petra.m_chgDate       = (Timestamp)dataValues[idx++].getObject();}
                if (isFetchedAttribute("County"))        {petra.m_county        = dataValues[idx++].getString();}
                if (isFetchedAttribute("Completion"))    {petra.m_completion    = (Timestamp)dataValues[idx++].getObject();}
                if (isFetchedAttribute("FieldName"))     {petra.m_fieldName     = dataValues[idx++].getString();}
                if (isFetchedAttribute("FMatTD"))        {petra.m_fMatTD        = dataValues[idx++].getString();}
                if (isFetchedAttribute("HistOper"))      {petra.m_histOper      = dataValues[idx++].getString();}
                if (isFetchedAttribute("LeaseName"))     {petra.m_leaseName     = dataValues[idx++].getString();}
                if (isFetchedAttribute("LeaseNbr"))      {petra.m_leaseNbr      = dataValues[idx++].getString();}
                if (isFetchedAttribute("Operator"))      {petra.m_operator      = dataValues[idx++].getString();}
                if (isFetchedAttribute("ProdFM"))        {petra.m_prodFM        = dataValues[idx++].getString();}
                if (isFetchedAttribute("Remarks"))       {petra.m_remarks       = dataValues[idx++].getString();}
                if (isFetchedAttribute("State"))         {petra.m_state         = dataValues[idx++].getString();}
                if (isFetchedAttribute("SymCode"))       {petra.m_symCode       = dataValues[idx++].getString();}
                if (isFetchedAttribute("uwi"))           {petra.m_uwi           = dataValues[idx++].getString();}
                if (isFetchedAttribute("$fileinputname$Label"))     {petra.m_wellLabel     = dataValues[idx++].getString();}
                if (isFetchedAttribute("$fileinputname$Name"))      {petra.m_wellName      = dataValues[idx++].getString();}
                if (isFetchedAttribute("$fileinputname$Number"))    {petra.m_wellNumber    = dataValues[idx++].getString();}
                if (isFetchedAttribute("Spud"))          {petra.m_spud          = (Timestamp)dataValues[idx++].getObject();}
                if (isFetchedAttribute("TD"))            {petra.m_tD            = doubleQty(dataValues[idx++]);}
                if (isFetchedAttribute("Datum"))         {petra.m_datum         = doubleQty(dataValues[idx++]);}
                if (isFetchedAttribute("DatumCode"))     {petra.m_datumCode     = dataValues[idx++].getString();}
                if (isFetchedAttribute("osp_ELEV_GR"))   {petra.m_osp_ELEV_GR   = doubleQty(dataValues[idx++]);}
                if (isFetchedAttribute("osp_ELEV_DF"))   {petra.m_osp_ELEV_DF   = doubleQty(dataValues[idx++]);}
                if (isFetchedAttribute("osp_ELEV_KB"))   {petra.m_osp_ELEV_KB   = doubleQty(dataValues[idx++]);}
                if (isFetchedAttribute("osp_ELEV_SEIS")) {petra.m_osp_ELEV_SEIS = doubleQty(dataValues[idx++]);}
            } catch (com.openspirit.InvalidTypeException e) {
                s_log.severe("Programming error: Caught InvalidTypeException: " + e.getDescription()
                             + ", details: " + e.getDetails(), e);
            }

            return petra;
        }

        /**
         * @see com.openspirit.plugin.data.petra.v3.mapped.PetraAccessCache#clearCache()
         *      {@inheritDoc}
         */
        protected void clearCache() {
            s_log.debug("Clearing cache for '" + TABLE + "'.");

            s_cache.clearCache();
        }

        /**
         * Clears the specified element from the cache.
         *
         * @param $1key$ the $fileinputname$ id to clear.
         */
        @SuppressWarnings("boxing")
        private static void clear(int $1key$) {
            try {
                s_cache.writeLock();

                s_cache.getMap().remove($1key$);
            } finally {
                s_cache.releaseLock();
            }

        }
        /**
         * Reads the well row with the specified id. 
         * Note: This method is used by the well bore inserter to check of the well 
         * location exists. Since this call may be time consuming use with caution!
         * 
         * @param the well id.
         * @return the petra object or null.
         */
        public $fileinputname$ readById(Integer id) {
            $fileinputname$ result = null;

            try {
                read(ID + " = " + id);

                result = next();
            } catch (com.openspirit.data.OspSQLException e) {
                s_log.severe("Caught OspSQLException: " + e.getMessage(), e);
            } finally {
                close();
            }

            return result;
        }


        /**
         * Returns the $fileinputname$ object with the specified id.
         *
         * @param id the $fileinputname$ id.
         * @return the $fileinputname$ object with the specified id.
         */
        public $fileinputname$ get(int $1key$) {
            s_log.debug("Getting element from " + TABLE + " with $1key$ " + $1key$);

            $fileinputname$ result = null;

            // Try getting the key from the cache.
            try {
                s_cache.readLock();

                result = s_cache.getMap().get($1key$);
            } finally {
                s_cache.releaseLock();
            }

            // The requested $1key$ is not in the cache, read and return it.
            if (result == null) {
                try {
                    s_cache.writeLock();

                    read(ID +  " = " + $1key$);

                    // Traverse all results from the read with next() call and save them in the cache.
                    while ((result = next()) != null) {
                        s_cache.getMap().put(result.m_$1key$, result);
                    }

                    // Set result to the cache result.
                    result = s_cache.getMap().get($1key$);
                } catch (OspSQLException e) {
                    s_log.severe("Caught OspSQLException: " + e.getMessage(), e);
                    e.printStackTrace();
                } finally {
                    close();
                    s_cache.releaseLock();
                }
            }

            return result;
        }




        //---------------------------------------------------------------------------------------------------------------------------
        /**
         * Inserts the specified row in the $fileinputname$ table with the specified values.
         *
         * @param var$fileinputname$ the object holding the insert values.
         * @return the new id.
         * @throws com.openspirit.spi.data.table.QueryException if the insert fails.
         */
        public int insert($fileinputname$ var$fileinputname$) throws QueryException {
            s_log.debug("Entered insert()");

            int newWsn = -1;

            com.openspirit.spi.data.QueryExecutor executor = null;
            com.openspirit.spi.data.QueryResult result = null;

            try {
                final String[] insertCols = new String[] {
                    "County"
                    , "FieldName"
                    , "FMatTD"
                    , "HistOper"
                    , "LeaseName"
                    , "LeaseNbr"
                    , "Operator"
                    , "ProdFM"
                    , "Remarks"
                    , "State"
                    , "SymCode"
                    , "uwi"
                    , "$fileinputname$Label"
                    , "$fileinputname$Name"
                    , "$fileinputname$Number"
                    , "Spud"
                    , "Completion"
                    , "TD"
                    , "osp_ELEV_GR"
                    , "osp_ELEV_DF"
                    , "osp_ELEV_KB"
                    , "osp_ELEV_SEIS"
                    , "Datum"
                    , "DatumCode"
                };

                final String sql = formatInsertStatement(TABLE, insertCols);
                s_log.debug("Native SQL Statement: " + sql);

                executor = nativeQueryExecutor(sql);
                com.openspirit.spi.data.QueryParameters params = queryParams(insertCols.length);

                int idx = 1;
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_county));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_fieldName));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_fMatTD));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_histOper));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_leaseName));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_leaseNbr));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_operator));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_prodFM));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_remarks));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_state));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_symCode));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_uwi));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_wellLabel));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_wellName));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_wellNumber));
                params.setParameterValue(idx++, sdvu().timestamp(var$fileinputname$.m_spud));
                params.setParameterValue(idx++, sdvu().timestamp(var$fileinputname$.m_completion));
                params.setParameterValue(idx++, sdvu().doubleQty(var$fileinputname$.m_tD));
                params.setParameterValue(idx++, sdvu().doubleQty(var$fileinputname$.m_osp_ELEV_GR));
                params.setParameterValue(idx++, sdvu().doubleQty(var$fileinputname$.m_osp_ELEV_DF));
                params.setParameterValue(idx++, sdvu().doubleQty(var$fileinputname$.m_osp_ELEV_KB));
                params.setParameterValue(idx++, sdvu().doubleQty(var$fileinputname$.m_osp_ELEV_SEIS));
                params.setParameterValue(idx++, sdvu().doubleQty(var$fileinputname$.m_datum));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_datumCode));

                result = executor.executeQuery(params);

                if (result.next()) {
                    // There is only 1 row in the result set.
                    com.openspirit.spi.data.DataKey nativeKey = spiDataKey(result.getDataValuesSet().getSetableDataValues()[0]);
                    newWsn = nativeKey.getKeyValues()[0].getInt();
                }

                s_log.debug("Inserted row into " + TABLE + " id=" + newWsn);
            } catch (com.openspirit.data.OspSQLException e) {
                throwQueryException(e);
            } catch (com.openspirit.BadArgumentsException e) {
                s_log.severe("Programming error: Caught BadArgumentsException: " + e.getMessage(), e);
                throw new com.openspirit.OspRuntimeException("Programming error: " + e.getDescription(), e);
            } catch (com.openspirit.InvalidTypeException e) {
                s_log.severe("Programming error: Caught InvalidTypeException: " + e.getMessage(), e);
                throw new com.openspirit.OspRuntimeException("Programming error: " + e.getDescription(), e);
            } finally {
                QueryUtils.close(result, executor);
                clear(var$fileinputname$.m_$1key$);
                PetraDirectionalSurvey.clearCache(var$fileinputname$.m_$1key$);
            }

            s_log.debug("Leaving insert(), new well $1key$ id=" + newWsn);

            return newWsn;
        }

        //---------------------------------------------------------------------------------------------------------------------------
        /**
         * Updates the specified row in the table with the specified values.
         * @param var$fileinputname$ the object holding the update values..
         * @throws com.openspirit.spi.data.table.QueryException if the update fails.
         */
        public void update($fileinputname$ var$fileinputname$) throws QueryException {
            s_log.debug("Entered update()");

            //String key = makeKey(m_stratColumn, m_unitName);
            com.openspirit.spi.data.QueryExecutor executor = null;
            com.openspirit.spi.data.QueryResult result = null;

            try {
                final String[] updateCols = new String[] {
                    "County"
                    , "FieldName"
                    , "FMatTD"
                    , "HistOper"
                    , "LeaseName"
                    , "LeaseNbr"
                    , "Operator"
                    , "ProdFM"
                    , "Remarks"
                    , "State"
                    , "SymCode"
                    , "uwi"
                    , "$fileinputname$Label"
                    , "$fileinputname$Name"
                    , "$fileinputname$Number"
                    , "Spud"
                    , "Completion"
                    , "TD"
                    , "osp_ELEV_GR"
                    , "osp_ELEV_DF"
                    , "osp_ELEV_KB"
                    , "osp_ELEV_SEIS"
                    , "Datum"
                    , "DatumCode"
                };

                final String sql = formatUpdateStatement(TABLE, updateCols)
                    + " WHERE " + ID + " = " + var$fileinputname$.m_$1key$;
                s_log.debug("Native SQL Statement: " + sql);

                com.openspirit.spi.data.QueryParameters params = queryParams(updateCols.length);
                int idx = 1;
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_county));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_fieldName));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_fMatTD));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_histOper));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_leaseName));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_leaseNbr));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_operator));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_prodFM));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_remarks));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_state));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_symCode));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_uwi));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_wellLabel));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_wellName));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_wellNumber));
                params.setParameterValue(idx++, sdvu().timestamp(var$fileinputname$.m_spud));
                params.setParameterValue(idx++, sdvu().timestamp(var$fileinputname$.m_completion));
                params.setParameterValue(idx++, sdvu().doubleQty(var$fileinputname$.m_tD));
                params.setParameterValue(idx++, sdvu().doubleQty(var$fileinputname$.m_osp_ELEV_GR));
                params.setParameterValue(idx++, sdvu().doubleQty(var$fileinputname$.m_osp_ELEV_DF));
                params.setParameterValue(idx++, sdvu().doubleQty(var$fileinputname$.m_osp_ELEV_KB));
                params.setParameterValue(idx++, sdvu().doubleQty(var$fileinputname$.m_osp_ELEV_SEIS));
                params.setParameterValue(idx++, sdvu().doubleQty(var$fileinputname$.m_datum));
                params.setParameterValue(idx++, sdvu().stringVal(var$fileinputname$.m_datumCode));

                executor = nativeQueryExecutor(sql);
                result = executor.executeQuery(params);

                s_log.debug("Updated " + TABLE + " id=" + var$fileinputname$.m_$1key$);
            } catch (com.openspirit.data.OspSQLException e) {
                throwQueryException(e);
            } catch (com.openspirit.BadArgumentsException e) {
                s_log.severe("Programming error: Caught BadArgumentsException: " + e.getMessage(), e);
                throw new com.openspirit.OspRuntimeException("Programming error: " + e.getDescription(), e);
            } finally {
                QueryUtils.close(result, executor);
                clear(var$fileinputname$.m_$1key$);
                PetraDirectionalSurvey.clearCache(var$fileinputname$.m_$1key$);
            }

            s_log.debug("Removing updated element from the cache");
            s_log.debug("Leaving update().");
        }

        /**
         * Deletes the specified row from the $fileinputname$ table.
         *
         * @param $1key$ the $fileinputname$ $1key$.
         */
        public void delete(Integer $1key$) throws com.openspirit.spi.data.table.QueryException {
            s_log.debug("Entered delete(), $1key$=" + $1key$);

            com.openspirit.spi.data.QueryExecutor executor = null;
            com.openspirit.spi.data.QueryResult result = null;

            try {
                final String sql = "DELETE FROM " + TABLE + " "
                    + "WHERE " + ID + " = " + $1key$.toString();

                s_log.debug("Native query: " + sql);
                executor = nativeQueryExecutor(sql);
                result = executor.executeQuery(null);

                s_log.debug("Deleted " + TABLE + " $1key$=" + $1key$);
            } catch (com.openspirit.data.OspSQLException e) {
                throwQueryException(e);
            } finally {
                QueryUtils.close(result, executor);
            }

            s_log.debug("Removing deleted element from the cache");
            clear($1key$);
            PetraDirectionalSurvey.clearCache($1key$);
            s_log.debug("Leaving delete().");
        }

        // $fileinputname$Aliases and $fileinputname$AliasTypes mapping
        public void populateAliasAttributes(final $fileinputname$ well, java.util.Vector<String> aliases, java.util.Vector<String> aliasTypes) {
            if (well.m_wellLabel != null && !well.m_wellLabel.isEmpty()) {
                aliases.add(well.m_wellLabel);
                aliasTypes.add("Common Name");
            }

            if (well.m_wellName != null && !well.m_wellName.isEmpty()) {
                aliases.add(well.m_wellName);
                aliasTypes.add("$fileinputname$ Name");
            }

            if (well.m_wellNumber != null && !well.m_wellNumber.isEmpty()) {
                aliases.add(well.m_wellNumber);
                aliasTypes.add("$fileinputname$ Number");
            }
        }

        /**
         * Returns the row count of the gdi table.
         * 
         * @param ids the IDs to find.
         */
        public int countRowsByIds(java.util.Collection<Integer> ids) {
            s_log.debug("Entered countRowsByIds()");

            return countRows(QueryUtils.inClauseInts(ID, ids));
        }

        /**
         * Returns the row count of the gdi table.
         * 
         * @param ids the IDs to find.
         */
        public int countRowsByUwis(java.util.Collection<String> uwis) {
            s_log.debug("Entered countRowsByUwis()");

            return countRows(QueryUtils.inClauseStrings("uwi", uwis));
        }

        /**
         * Returns the row count of the gdi table.
         * 
         * @param names the names to find.
         */
        public int countRowsByNames(java.util.Collection<String> names) {
            s_log.debug("Entered countRowsByNames()");

            return countRows(QueryUtils.inClauseStrings("$fileinputname$Label", names));
        }

        /**
         * Sets what related attributes need to be fetched during read.
         * @param needLocAttrs TODO
         * @param needDirSAttrs 
         * @param needPickAttrs TODO
         * @param needZoneAttrs TODO
         * @param needLogAttrs TODO
         */
        public void setRelatedAttributesToFetch(boolean needLocAttrs, boolean needDirSAttrs, boolean needPickAttrs, boolean needZoneAttrs, boolean needLogAttrs) {
            m_needLocAttrs = needLocAttrs;
            m_needDirSAttrs = needDirSAttrs;
            m_needPickAttrs = needPickAttrs;
            m_needZoneAttrs = needZoneAttrs;
            m_needLogAttrs = needLogAttrs;
        }

        /**
         * @see com.openspirit.plugin.data.petra.v3.mapped.petra.PetraReader#fetchRelatedAttributes()
         * {@inheritDoc}
         */
        @Override
        protected void fetchRelatedAttributes() {
            if (m_cache == null || m_cache.size() == 0) {
                s_log.debug("Empty cache in fetchRelatedAttributes() nothing to do, returning.");
                return;
            }

            s_log.debug("Fetching related attributes for " + m_cache.size() + " rows.");

            if (!m_needLocAttrs &&
                !m_needDirSAttrs &&
                !m_needPickAttrs &&
                !m_needZoneAttrs &&
                !m_needLogAttrs) {            
                s_log.debug("All related attribute flags are false, nothing to do.");

                return;
            }

            // Create a local map for easy access to the Gdi$fileinputname$Entire elements.
            java.util.Map<Integer, $fileinputname$> localMap =
                new java.util.HashMap<Integer, $fileinputname$>(m_cache.size());

            for ($fileinputname$ elem: m_cache) {
                localMap.put(elem.m_$1key$, elem);
            }

            if (m_needLocAttrs) {
                final Loc tableAccess = new Loc(petra3TableConnection());
                Loc result = null;

                tableAccess.readByWsns(localMap.keySet());

                try {
                    while ((result = tableAccess.next()) != null) {
                        // Get the well from the cache.
                        $fileinputname$ elem = localMap.get(result.m_$1key$);
                        elem.m_wellLoc = result;
                    }
                } catch (OspSQLException e) {
                    s_log.severe("Caught SQL exception while populating wells: " + e.getMessage(), e);
                    e.printStackTrace();
                }
                finally {
                    tableAccess.close();
                }
            }
            
            if (m_needDirSAttrs) {
                s_log.debug("Collecting DirSrvHdr objects.");

                fetchDirSrvHdrObjs(localMap.keySet());
            }

            if (m_needPickAttrs) {
                s_log.debug("Collecting $fileinputname$Pick objects...");

                fetchFormTopObjs(localMap);
            }
            if (m_needZoneAttrs) {
                s_log.debug("Collecting OSP_$fileinputname$Zone objects...");

                fetchZoneObjs(localMap);
            }
            if (m_needLogAttrs) {
                s_log.debug("Collecting Log objects...");

                fetchLogObjs(localMap);
            }        
        }

        private void fetchLogObjs(java.util.Map<Integer, $fileinputname$> localMap) {
            final $fileinputname$Log tableAccess = new $fileinputname$Log(petra3TableConnection());
            $fileinputname$Log result = null;

            // We need only the primary key attributes.
            tableAccess.setAttributesToFetch(new String[] { "$1key$", "LSN" });

            tableAccess.readByWsns(localMap.keySet());

            try {
                while ((result = tableAccess.next()) != null) {
                    // Get the well from the cache.
                    $fileinputname$ elem = localMap.get(result.m_$1key$);

                    if (elem.m_wellLogs == null) {
                        elem.m_wellLogs = new java.util.ArrayList<$fileinputname$Log>();
                    }
                    elem.m_wellLogs.add(result);
                }
            } catch (OspSQLException e) {
                s_log.severe("Caught SQL exception while populating wells: " + e.getMessage(), e);
                e.printStackTrace();
             }
             finally {
                tableAccess.close();
            }
        }

        private void fetchZoneObjs(java.util.Map<Integer, $fileinputname$> localMap) {
            final OSP_$fileinputname$Zone tableAccess = new OSP_$fileinputname$Zone(petra3TableConnection());
            OSP_$fileinputname$Zone result = null;

            // We need only the primary key attributes.
            tableAccess.setAttributesToFetch(new String[] { "$1key$", "ZID" });

            tableAccess.readByWsns(localMap.keySet());

            try {
                while ((result = tableAccess.next()) != null) {
                    // Get the well from the cache.
                    $fileinputname$ elem = localMap.get(result.m_$1key$);

                    if (elem.m_wellZones == null) {
                        elem.m_wellZones = new java.util.ArrayList<OSP_$fileinputname$Zone>();
                    }
                    elem.m_wellZones.add(result);
                }
            } catch (OspSQLException e) {
                s_log.severe("Caught SQL exception while populating wells: " + e.getMessage(), e);
                e.printStackTrace();
             }
             finally {
                tableAccess.close();
            }
        }

        private void fetchFormTopObjs(Map<Integer, $fileinputname$> localMap) {
            final FormationTop tableAccess = new FormationTop(petra3TableConnection());
            FormationTop result = null;

            // We need only the primary key attributes.
            tableAccess.setAttributesToFetch(new String[] { "$1key$", "FID" });

            tableAccess.readByWsns(localMap.keySet());

            try {
                while ((result = tableAccess.next()) != null) {
                    // Get the well from the cache.
                    $fileinputname$ elem = localMap.get(result.m_$1key$);

                    if (elem.m_petraPicks == null) {
                        elem.m_petraPicks = new java.util.ArrayList<FormationTop>();
                    }
                    elem.m_petraPicks.add(result);
                }
            } catch (OspSQLException e) {
                s_log.severe("Caught SQL exception while populating wells: " + e.getMessage(), e);
                e.printStackTrace();
            }
            finally {
                tableAccess.close();
            }
        }

        private void fetchDirSrvHdrObjs(java.util.Set<Integer> wellIds) {
            final DirSrvHdr tableAccess = new DirSrvHdr(petra3TableConnection());
            DirSrvHdr result = null;

            tableAccess.readByWsns(wellIds);

            try {

                java.util.Map<Integer, DirSrvHdr> localMap = new java.util.HashMap<Integer, DirSrvHdr>(m_cache.size());

                // Create DirSrvHdralMap from the results
                while ((result = tableAccess.next()) != null) {
                    localMap.put(result.m_$1key$, result);
                }

                for ($fileinputname$ elem: m_cache) {
                    // Get the DirSrvHdration from the DirSrvHdralMap.
                    elem.m_dirSrvHdr = localMap.get(elem.m_$1key$);
                }

            } catch (OspSQLException e) {
                s_log.severe("Caught SQL exception while populating wells: " + e.getMessage(), e);
                e.printStackTrace();
            } finally {
                tableAccess.close();
            }
        }
    }
}
