/*========================================================================
 * - COPYRIGHT NOTICE -                                                  *
 *                                                                       *
 * (c) Copyright 2000-2016 TIBCO Software Inc. All rights reserved.      *
 * TIBCO Confidential & Proprietary                                      *
 *                                                                       *
 ========================================================================*/

package com.openspirit.plugin.data.petra.v3.mapped.petra;

import java.util.ArrayList;

import com.openspirit.plugin.data.common.MapCacheWithTimeout;
import com.openspirit.plugin.data.common.QueryUtils;
import com.openspirit.plugin.data.petra.v3.mapped.Petra3TableConnection;
import com.openspirit.plugin.data.petra.v3.mapped.Petra3Utils;

/**
 * Class implementation for the $fileinputname$ table.
 */
public final class $fileinputname$ {

    /**
     * The native entity name.
     */
    public final static String TABLE = "$fileinputname$";

    /**
     * The name of the primary key attribute.
     */
    public static final String ID = "$keyName$";

    // Members are named 'm_' + the petra attribute name.
    public $keyType$ m_$keyName$;
    public int[] m_wsnList;

    /**
     * Constructor.
     *
     * @param connection the connection.
     */
    public $fileinputname$() {
    }

    /**
     * Access class for $fileinputname$.
     */
    public static class Factory extends PetraAccessCache {

        private static com.openspirit.spi.logging.Logger s_log =
            com.openspirit.spi.SingletonFactory.getLogger(Factory.class);

        // cache of well objects
        private static MapCacheWithTimeout<String, $fileinputname$> s_cache = new MapCacheWithTimeout<String, $fileinputname$>();

        /**
         * Constructor.
         * 
         * @param tableConnection the table connection.
         */
        public Factory(Petra3TableConnection tableConnection) {
            super(tableConnection);

            s_log.debug("Entered constructor()");
        }

        /**
         * @see com.openspirit.plugin.data.petra.v3.mapped.PetraAccessCache#clearCache()
         *      {@inheritDoc}
         */
        @Override
        protected void clearCache() {
            s_log.debug("Clearing cache for '" + TABLE + "'.");

            s_cache.clearCache();
        }

        /**
         * Clears the specified element from the cache.
         *
         * @param $keyName$ the $fileinputname$ id to clear.
         */
        @SuppressWarnings("boxing")
        private static void clear(String $keyName$) {
            try {
                s_cache.writeLock();

                s_cache.getMap().remove($keyName$);
            }
            finally {
                s_cache.releaseLock();
            }
        }

        /**
         * Returns the $fileinputname$ object with the specified id.
         *
         * @param id the $fileinputname$ id.
         * @return the $fileinputname$ object with the specified id.
         */
        public $fileinputname$ get(String $keyName$) {
            s_log.debug("Getting element from " + TABLE + " with $keyName$ " + $keyName$);

            $fileinputname$ result = null;

            try {
                s_cache.readLock();

                result = s_cache.getMap().get($keyName$);
            }
            finally {
                s_cache.releaseLock();
            }

            // The requested $keyName$ is not in the cache, read and return it.
            if (result == null) {
                try {
                    s_cache.writeLock();

                    read(" WHERE $keyName$ = '" + quoteString($keyName$) + "'");

                    return s_cache.getMap().get($keyName$);
                }
                finally {
                    s_cache.releaseLock();
                }
            }

            return result;
        }

        /**
         * Reads all $fileinputname$ rows.
         *
         * @return all $fileinputname$ object ids.
         */
        public ArrayList<String> read() {
            try {
                s_cache.writeLock();

                return read(null);
            }
            finally {
                s_cache.releaseLock();
            }
        }

        /**
         * Reads the $fileinputname$ ids with the name specified in the constraintNames list.
         *
         * @param constraintNames
         * @return java.util.List<String> ids matching the specified filter..
         */
        public ArrayList<String> readBy$keyName$s(java.util.List<String> constraintNames) {
            String whereClause = null;

            if (constraintNames != null && constraintNames.size() > 0) {
                whereClause = " WHERE " + QueryUtils.inClauseStrings(ID, constraintNames);
            }

            try {
                s_cache.writeLock();
                return read(whereClause);
            }
            finally {
                s_cache.releaseLock();
            }
        }

        private ArrayList<String> read(String whereClause) {
            ArrayList<String> resultList = new java.util.ArrayList<String>();

            s_log.debug("Entered read()");

            com.openspirit.spi.data.QueryExecutor executor = null;
            com.openspirit.spi.data.QueryResult result = null;

            try {
                // Retrieve the relevant attributes that are used for OSP mappingsString
                StringBuilder sql = new StringBuilder();
                sql.append("SELECT "
                           + "$keyName$"
                           + ", wsnList"
                           + " FROM " + TABLE);

                if (whereClause != null && whereClause.length() > 0) {
                    sql.append(whereClause);
                }

                executor = nativeQueryExecutor(sql.toString());
                result = executor.executeQuery(null);

                while (result.next()) {
                    $fileinputname$ petra = new $fileinputname$();

                    com.openspirit.spi.data.type.SetableDataValue[] dataValues = result
                        .getDataValuesSet().getSetableDataValues();

                    // WARNING: Must be in same order as the above select columns
                    int idx = 0;
                    petra.m_$keyName$ = dataValues[idx++].getString();
                    petra.m_wsnList = intArray(dataValues[idx++]);

                    s_cache.getMap().put(petra.m_$keyName$, petra);
                    resultList.add(petra.m_$keyName$);
                }
            }
            catch (com.openspirit.data.OspSQLException e) {
                s_log.severe("Programming error: Caught OspSQLException: "
                             + e.getMessage(), e);
            }
            catch (Exception e) {
                s_log.severe("Programming error: Caught OspSQLException: "
                             + e.getMessage(), e);
            }
            finally {
                QueryUtils.close(result, executor);
            }

            s_log.debug("Leaving read(), row number=" + resultList.size());

            return resultList;
        }

        /**
         * Deletes the specified row from the $fileinputname$ table.
         *
         * @param $keyName$ the $fileinputname$ $keyName$.
         */
        public void delete(String $keyName$) throws com.openspirit.spi.data.table.QueryException {
            s_log.debug("Entered delete(), $keyName$=" + $keyName$);

            com.openspirit.spi.data.QueryExecutor executor = null;
            com.openspirit.spi.data.QueryResult result = null;

            try {
                final String sql = "DELETE FROM " + TABLE + " "
                    + "WHERE " + ID + " = " + $keyName$.toString();

                executor = nativeQueryExecutor(sql);
                result = executor.executeQuery(null);

                s_log.debug("Deleted " + TABLE + " $keyName$=" + $keyName$);
            }
            catch (com.openspirit.data.OspSQLException e) {
                s_log.severe("Caught OspSQLException: " + e.getMessage(), e);

                Petra3Utils.throwQueryException(e);
            }
            finally {
                QueryUtils.close(result, executor);
            }

            s_log.debug("Removing deleted element from the cache");
            clear($keyName$);
            s_log.debug("Leaving delete().");
        }
    }
}
